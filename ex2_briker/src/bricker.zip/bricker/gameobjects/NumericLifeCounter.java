package bricker.gameobjects;

import danogl.GameObject;
import danogl.gui.rendering.Renderable;
import danogl.util.Vector2;

/**
 * This class is responsible for the life in the game.
 * The class can add a number of life, or sub the number of life.
 */
public class NumericLifeCounter extends GameObject {
    private int lifeCounter;


    public NumericLifeCounter(Vector2 topLeftCorner, Vector2 dimensions,
                              Renderable renderable, int numberOfLifes){
        super(topLeftCorner , dimensions , renderable);
        this.lifeCounter = numberOfLifes;
    }

    public void removeLife(){
        this.lifeCounter--;

    }
    public int getLife(){
        return this.lifeCounter;
    }

    public void addLife(){
        this.lifeCounter++;
    }

}
