package bricker.gameobjects;

import bricker.brick_strategies.BasicCollisionStrategy;
import danogl.GameObject;
import danogl.collisions.GameObjectCollection;
import danogl.gui.rendering.Renderable;
import danogl.util.Counter;
import danogl.util.Vector2;

/**
 * This class responsible to crate a matrix of bricks and to
 * count the number of the current bricks
 */
public class MatrixBricks {
    private static final int BORDER_WIDTH = 10;
    private static final int SPACE_BETWEEN_BRICKS = 5;
    private static final int SPACE_BETWEEN_ROWS_BRICKS = 5;
    private int brickRows;
    private int brickInEachRow;
    private Vector2 windowDimensions;
    private Counter countCurrentBricks;
    private static final int HIGHT_OF_BRICKS = 15;
    private GameObjectCollection gameObject;


    public MatrixBricks( Renderable renderable,
                        Vector2 windowDimensions, int brickRows, int brickInEachRow,
                         GameObjectCollection gameObject){
//        super(topLeftCorner, dimensions, renderable); //call the constructor
        this.windowDimensions = windowDimensions;
        this.brickRows = brickRows;
        this.brickInEachRow = brickInEachRow;
        this.countCurrentBricks = new Counter();
        this.gameObject = gameObject;
        createBrickMatrix(renderable);
    }

    private void createBrickMatrix(Renderable brickImage){
        float x = windowDimensions.x(); //get x dimension
        float y = windowDimensions.y(); //get y dimension
        x = x - (2 * BORDER_WIDTH) - ((2 + brickInEachRow-1)* SPACE_BETWEEN_BRICKS);
        //TODO:check if the size is correct
        float widthOfBricks = x / brickInEachRow;
        float startingOfBricks = BORDER_WIDTH + SPACE_BETWEEN_BRICKS;

            for(int row = 0 ; row < brickRows ; row++ ){
            for(int rowIndex = 0 ; rowIndex < brickInEachRow ; rowIndex++){
                float xStartIndex = startingOfBricks + rowIndex*(widthOfBricks+SPACE_BETWEEN_BRICKS);
                //this vector is the location of the brick
                Vector2 startIndex = new Vector2( xStartIndex, SPACE_BETWEEN_ROWS_BRICKS+BORDER_WIDTH + row * (SPACE_BETWEEN_ROWS_BRICKS+HIGHT_OF_BRICKS));
                createBrick(brickImage ,startIndex ,new Vector2(widthOfBricks ,HIGHT_OF_BRICKS ));
                this.countCurrentBricks.increment(); //increase the number of bricks
            }
        }
    }

    public boolean isMatrixEmpty(){
        if(countCurrentBricks.value() == 0){
            return true;
        }
        return false;
    }

    private void createBrick(Renderable brickImage ,Vector2 startingPosition ,Vector2 size){
        Brick brick = new Brick(startingPosition ,
                size,
                brickImage,
                new BasicCollisionStrategy(gameObject), countCurrentBricks);
        gameObject.addGameObject(brick);
    }
}
