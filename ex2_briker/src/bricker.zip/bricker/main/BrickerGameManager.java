package bricker.main;

import bricker.brick_strategies.BasicCollisionStrategy;
import bricker.gameobjects.*;
import danogl.GameManager;
import danogl.GameObject;
import danogl.gui.*;
import danogl.gui.rendering.RectangleRenderable;
import danogl.gui.rendering.Renderable;
import danogl.util.Counter;
import danogl.util.Vector2;

import java.awt.*;
import java.util.Random;

public class BrickerGameManager extends GameManager {

    private static final int DEFAULT_ROWS_OF_BRICK = 7;
    private static final int DEFUALT_LIFE = 3;
    private static final int HIGHT_OF_BRICKS = 15;
    private static final int SPACE_BETWEEN_BRICKS = 5;
    private static final int SPACE_BETWEEN_ROWS_BRICKS = 5;
    private static final int DEFAULT_BRICKS_IN_ROW = 8;
    private static final int BORDER_WIDTH = 10;
    private static final int PADDLE_HEIGHT = 20;
    private static final int PADDLE_WIDTH = 100;
    private static final int BALL_RADIUS = 35;
    private static final float BALL_SPEED = 350;
    private static final Renderable BORDER_RENDERABLE =
            new RectangleRenderable(new Color(80, 140, 250));
    private MatrixBricks matrixBricks;
    private NumericLifeCounter lifeCounter;
    private Ball ball;
    private Vector2 windowDimensions;
    private WindowController windowController;
    private int brickRows;
    private int brickInEachRow;

    public BrickerGameManager(String windowTitle, Vector2 windowDimensions,
                              int brickRows , int brickInEachRow ) {
        super(windowTitle, windowDimensions);
        this.brickRows = brickRows;
        this.brickInEachRow = brickInEachRow;
    }

    @Override
    public void initializeGame(ImageReader imageReader,
                               SoundReader soundReader,
                               UserInputListener inputListener,
                               WindowController windowController) {
        this.windowController = windowController;
        //initialization
        super.initializeGame(imageReader, soundReader, inputListener, windowController);
        windowDimensions = windowController.getWindowDimensions();

        //create ball
        createBall(imageReader, soundReader, windowController);

        //create paddles
        Renderable paddleImage = imageReader.readImage(
                "assets/paddle.png", false);
        createUserPaddle(paddleImage, inputListener, windowDimensions);

        //create life counter
        Renderable heartImage = imageReader.readImage(
                "assets/heart.png", true);
        createLifeCounter(heartImage,DEFUALT_LIFE);

        //create brick
        Renderable brickImage =
                imageReader.readImage("assets/brick.png", false);
        this.matrixBricks =new MatrixBricks(brickImage , windowDimensions , 1 , 1,gameObjects());

        //create borders
        createBorders(windowDimensions);
    }

//    /**
//     * This function calculate the size of each brick and create the brick
//     * @param brickImage: the image of the brick
//     */
//    private void createBrickMatrix(Renderable brickImage){
//        float x = windowDimensions.x(); //get x dimension
//        float y = windowDimensions.y(); //get y dimension
//        x = x - (2 * BORDER_WIDTH) - ((2 + brickInEachRow-1)* SPACE_BETWEEN_BRICKS);
//        //TODO:check if the size is correct
//        float widthOfBricks = x / brickInEachRow;
//        float startingOfBricks = BORDER_WIDTH + SPACE_BETWEEN_BRICKS;
//
//        for(int row = 0 ; row < brickRows ; row++ ){
//            for(int rowIndex = 0 ; rowIndex < brickInEachRow ; rowIndex++){
//                float xStartIndex = startingOfBricks + rowIndex*(widthOfBricks+SPACE_BETWEEN_BRICKS);
//                //this vector is the location of the brick
//                Vector2 startIndex = new Vector2( xStartIndex, SPACE_BETWEEN_ROWS_BRICKS+BORDER_WIDTH + row * (SPACE_BETWEEN_ROWS_BRICKS+HIGHT_OF_BRICKS));
//                createBrick(brickImage ,startIndex ,new Vector2(widthOfBricks ,HIGHT_OF_BRICKS ));
//                this.countCurrentBricks.increment(); //increase the number of bricks
//            }
//        }
//    }

    @Override
    public void update(float deltaTime) {
        super.update(deltaTime);
        checkForGameEnd();
    }
    private void createLifeCounter(Renderable renderable, int numberOfLifes){
        Vector2 startingPosition = Vector2.ZERO;
        Vector2 dimensions = new Vector2(10 , 10);

        lifeCounter = new NumericLifeCounter(startingPosition, dimensions,
                renderable, numberOfLifes);
        gameObjects().addGameObject((lifeCounter));


    }
//    private void createBrick(Renderable brickImage ,Vector2 startingPosition ,Vector2 size){
//
//        Brick brick = new Brick(startingPosition ,
//                size,
//                brickImage,
//                new BasicCollisionStrategy(gameObjects()) ,
//                countCurrentBricks);
//        gameObjects().addGameObject(brick);
//    }

    private void checkForGameEnd() {
        double ballHeight = ball.getCenter().y();
        String prompt = "";
//        we win
        if(thmatrixBricks.isMatrixEmpty()){
            prompt = "You win!";
        }
        if(ballHeight > windowDimensions.y()) {
            //we lose
            lifeCounter.removeLife();
            if(lifeCounter.getLife() == 0){
                prompt = "You Lose!";
            }
            else {
                ball.setCenter(windowDimensions.mult(0.5f));
            }
        }
        if(!prompt.isEmpty()) {
            prompt += " Play again?";
            if(windowController.openYesNoDialog(prompt))
                windowController.resetGame();
            else
                windowController.closeWindow();
        }
    }

    private void createBall(ImageReader imageReader, SoundReader soundReader, WindowController windowController) {
        Renderable ballImage =
                imageReader.readImage("assets/ball.png", true);
        Sound collisionSound = soundReader.readSound("assets/blop.wav");
        ball = new Ball(
                Vector2.ZERO, new Vector2(BALL_RADIUS, BALL_RADIUS), ballImage, collisionSound);

        Vector2 windowDimensions = windowController.getWindowDimensions();
        ball.setCenter(windowDimensions.mult(0.5f));
        gameObjects().addGameObject(ball);

        float ballVelX = BALL_SPEED;
        float ballVelY = BALL_SPEED;
        Random rand = new Random();
        if(rand.nextBoolean())
            ballVelX *= -1;
        if(rand.nextBoolean())
            ballVelY *= -1;
        ball.setVelocity(new Vector2(ballVelX, ballVelY));
    }

    private void createUserPaddle(Renderable paddleImage, UserInputListener inputListener, Vector2 windowDimensions) {
        GameObject userPaddle = new UserPaddle(
                Vector2.ZERO,
                new Vector2(PADDLE_WIDTH, PADDLE_HEIGHT),
                paddleImage,
                inputListener);
        gameObjects();
        userPaddle.setCenter(
                new Vector2(windowDimensions.x()/2, (int)windowDimensions.y()-30));
        gameObjects().addGameObject(userPaddle);
    }

    private void createBorders(Vector2 windowDimensions) {
        gameObjects().addGameObject(
                new GameObject(
                        new Vector2(0,0),
                        new Vector2(windowDimensions.x() , BORDER_WIDTH),
                        BORDER_RENDERABLE)
                );
        gameObjects().addGameObject(
                new GameObject(
                        Vector2.ZERO,
                        new Vector2(BORDER_WIDTH, windowDimensions.y()),
                        BORDER_RENDERABLE)
        );
        gameObjects().addGameObject(
                new GameObject(
                        new Vector2(windowDimensions.x()-BORDER_WIDTH, 0),
                        new Vector2(BORDER_WIDTH, windowDimensions.y()),
                        BORDER_RENDERABLE)
        );
    }

    public static void main(String[] args) {
        BrickerGameManager game;
        if (args.length == 0 ){ //if there is no arguments
            game = new BrickerGameManager(
                    "Bouncing Ball",
                    new Vector2(700, 500) ,
                    DEFAULT_ROWS_OF_BRICK ,
                    DEFAULT_BRICKS_IN_ROW);
            game.run();
        }
        else {
            game = new BrickerGameManager(
                    "Bouncing Ball",
                    new Vector2(700, 500) ,
                    Integer.valueOf(args[1]) ,
                    Integer.valueOf(args[0]));
            game.run();
        }

    }

}
